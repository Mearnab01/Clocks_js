setInterval(() => {
    clock();
}, 1000);

function clock() {
    var d = new Date();
    var hours = d.getHours();
    var min = d.getMinutes();
    var sec = d.getSeconds();
    let period = "AM"

    if(hours>=12){
        period="PM"
        hours=hours-12
    }
    if (hours<10){
        hours="0"+hours
    }
    if (min<10){
        min="0"+min
    }
    if (sec<10){
        sec="0"+sec
    }
    document.querySelector('.hour').innerHTML = hours;
    document.querySelector('.min').innerHTML = min;
    document.querySelector('.second').innerHTML = sec;
    document.querySelector('.period').innerHTML = period;
}



var today=new Date();
const dayNumber= today.getDate();
const year= today.getFullYear();
const dayName=today.toLocaleString('default',{weekday:"long"})
const monthName=today.toLocaleString('default',{month:"short"})

document.querySelector('.month-name').innerHTML=monthName;
document.querySelector('.day-name').innerHTML=dayName;
document.querySelector('.day-number').innerHTML=dayNumber;
document.querySelector('.year').innerHTML=year