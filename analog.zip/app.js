const hr = document.getElementById('hr');
const mn = document.getElementById('mn');
const sc = document.getElementById('sc');

setInterval(() => {
    let d = new Date()
    let hh = d.getHours();
    let mh = d.getMinutes();
    let sh = d.getSeconds();

    hr.style.transform = `rotateZ(${(hh*30) + (mh*0.5)}deg)`;
    mn.style.transform = `rotateZ(${(mh*6)+(0.1*sh)}deg)`;
    sc.style.transform = `rotateZ(${sh*6}deg)`;
}, 1000); 